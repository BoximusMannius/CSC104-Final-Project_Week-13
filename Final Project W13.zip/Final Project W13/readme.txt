Coalition of Cabbage Connoisseurs

Home Page:
Outputs a breife overview about cabbages, and links to the other pages

Info Page:
Outputs information about various types of cabbages, including their appearance. It also descirbes how they are used and why.

Recipe Page:
Outputs a bunch of different recipes that involve cabbage. It displayes all of the ingedients and the steps needed to make it. Images of the end result is also provided